import { useMemo, useState } from "react";

const API = (import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000").replace(/\/$/, "");

function FilePicker({ label, value, onChange }) {
  return <label className="file-picker">
    <span className="file-icon">＋</span>
    <span className="file-label">{label}</span>
    <span className="file-name">{value ? value.name : "Choose Takeout ZIP"}</span>
    <input type="file" accept=".zip,application/zip" onChange={e => onChange(e.target.files?.[0] || null)} />
  </label>;
}

function PhotoRow({ item, accountLabel }) {
  return <div className="photo-row">
    <div className="photo-symbol">▧</div>
    <div className="photo-info">
      <strong>{item.name}</strong>
      <small>{accountLabel} · {formatBytes(item.size)}{item.width && item.height ? ` · ${item.width}×${item.height}` : ""}</small>
    </div>
    <button className="tiny" onClick={() => navigator.clipboard?.writeText(item.path || item.name)}>Copy path</button>
  </div>;
}
function formatBytes(n = 0) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}
function downloadJSON(data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "phototwin-report.json"; a.click();
  URL.revokeObjectURL(url);
}

export default function App() {
  const [aFile, setAFile] = useState(null);
  const [bFile, setBFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [report, setReport] = useState(null);
  const [tab, setTab] = useState("exact");
  const [query, setQuery] = useState("");

  const rows = useMemo(() => {
    if (!report) return [];
    const map = {
      exact: report.exact_duplicates || [],
      similar: report.likely_similar || [],
      a: report.account_a_only || [],
      b: report.account_b_only || [],
    };
    const source = map[tab] || [];
    if (!query.trim()) return source;
    const q = query.toLowerCase();
    return source.filter(row => {
      const text = JSON.stringify(row).toLowerCase();
      return text.includes(q);
    });
  }, [report, tab, query]);

  async function runCompare(e) {
    e.preventDefault();
    setError(""); setReport(null);
    if (!aFile || !bFile) { setError("Choose a ZIP export for both accounts first."); return; }
    setLoading(true);
    try {
      const form = new FormData();
      form.append("account_a", aFile);
      form.append("account_b", bFile);
      const response = await fetch(`${API}/api/compare`, { method: "POST", body: form });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.detail || `Server error (${response.status})`);
      setReport(body);
      setTab("exact");
    } catch (err) {
      setError(`${err.message || "Could not compare exports."} Check the backend URL and upload size limits.`);
    } finally { setLoading(false); }
  }

  return <main className="shell">
    <header className="topbar">
      <div className="brand-mark">PT</div>
      <div><div className="brand">PhotoTwin</div><div className="tagline">Google Photos duplicate finder</div></div>
      <span className="status"><i /> Export scanner</span>
    </header>

    <section className="hero">
      <p className="eyebrow">YOUR PHOTOS. YOUR CONTROL.</p>
      <h1>Find the copies.<br /><span>Keep the memories.</span></h1>
      <p className="hero-copy">Compare two Google Photos Takeout ZIP exports to find exact duplicates, likely similar shots, and files unique to each account.</p>
    </section>

    <section className="card export-card">
      <div className="section-heading"><div><span className="step">01</span><h2>Prepare your exports</h2></div><span className="muted">Google authorizes exports</span></div>
      <ol className="instructions">
        <li>Open Google Takeout and sign in to Account A.</li>
        <li>Deselect everything, select <b>Google Photos</b>, then create the export.</li>
        <li>Repeat for Account B. Keep track of which ZIP belongs to which account.</li>
      </ol>
      <a className="button secondary" href="https://takeout.google.com/" target="_blank" rel="noreferrer">Open Google Takeout ↗</a>
      <p className="warning"><b>Phone storage note:</b> If your phone is nearly full, save the Takeout export to Google Drive. This first version accepts ZIP files selected from your device; direct Drive import is not yet included.</p>
    </section>

    <form className="card" onSubmit={runCompare}>
      <div className="section-heading"><div><span className="step">02</span><h2>Compare two accounts</h2></div></div>
      <div className="pickers">
        <FilePicker label="ACCOUNT A" value={aFile} onChange={setAFile} />
        <FilePicker label="ACCOUNT B" value={bFile} onChange={setBFile} />
      </div>
      <button className="button primary" type="submit" disabled={loading}>{loading ? <><span className="spinner" /> Scanning exports…</> : "Compare exports"}</button>
      {loading && <p className="muted">Large archives may take several minutes. Keep this page open.</p>}
      {error && <div className="error">{error}</div>}
      <p className="privacy-note">ZIPs are processed by your configured backend and temporary files are removed after the scan. Use only a private, trusted deployment for personal photos.</p>
    </form>

    {report && <>
      <section className="stats">
        <div className="stat"><span>Account A images</span><strong>{report.summary.account_a_images}</strong></div>
        <div className="stat"><span>Account B images</span><strong>{report.summary.account_b_images}</strong></div>
        <div className="stat highlight"><span>Exact duplicate groups</span><strong>{report.summary.exact_duplicate_hashes}</strong></div>
        <div className="stat"><span>Likely similar pairs</span><strong>{report.summary.likely_similar_pairs}</strong></div>
      </section>
      <section className="card results">
        <div className="section-heading"><div><span className="step">03</span><h2>Comparison report</h2></div><button className="tiny" onClick={() => downloadJSON(report)}>Export report JSON ↓</button></div>
        <div className="tabs">
          <button className={tab==="exact"?"active":""} onClick={() => setTab("exact")} type="button">Exact duplicates <b>{report.summary.exact_duplicate_hashes}</b></button>
          <button className={tab==="similar"?"active":""} onClick={() => setTab("similar")} type="button">Similar <b>{report.summary.likely_similar_pairs}</b></button>
          <button className={tab==="a"?"active":""} onClick={() => setTab("a")} type="button">A only <b>{report.summary.account_a_only_files}</b></button>
          <button className={tab==="b"?"active":""} onClick={() => setTab("b")} type="button">B only <b>{report.summary.account_b_only_files}</b></button>
        </div>
        <input className="search" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search filenames or paths…" />
        <p className="warning"><b>Review only:</b> PhotoTwin does not delete cloud photos. Exact duplicates are byte-identical files; similar matches may be different edits or burst shots.</p>
        <div className="result-list">
          {rows.length === 0 && <div className="empty">No matching entries in this section.</div>}
          {tab === "exact" && rows.map((group, i) => <div className="match-card" key={group.sha256}>
            <div className="match-title"><span className="match-badge">EXACT MATCH</span><small>Group {i + 1}</small></div>
            <div className="two-col"><div><b>Account A</b>{group.account_a.map((x, j) => <PhotoRow item={x} accountLabel="A" key={x.path+j} />)}</div><div><b>Account B</b>{group.account_b.map((x, j) => <PhotoRow item={x} accountLabel="B" key={x.path+j} />)}</div></div>
          </div>)}
          {tab === "similar" && rows.map((pair, i) => <div className="match-card" key={`${pair.account_a.path}-${pair.account_b.path}`}>
            <div className="match-title"><span className="match-badge similar">LIKELY SIMILAR</span><small>Visual distance {pair.distance}/64</small></div>
            <div className="two-col"><div><b>Account A</b><PhotoRow item={pair.account_a} accountLabel="A" /></div><div><b>Account B</b><PhotoRow item={pair.account_b} accountLabel="B" /></div></div>
          </div>)}
          {(tab === "a" || tab === "b") && rows.map((item, i) => <div className="single-row" key={item.path+i}><PhotoRow item={item} accountLabel={tab === "a" ? "A only" : "B only"} /></div>)}
        </div>
      </section>
    </>}

    <footer><span>PhotoTwin MVP · No automatic deletion</span><span>Built for safe comparison</span></footer>
  </main>;
}
