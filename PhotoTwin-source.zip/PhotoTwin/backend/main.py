import hashlib
import io
import os
import tempfile
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any

import imagehash
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, UnidentifiedImageError

APP_NAME = "PhotoTwin API"
MAX_ZIP_BYTES = int(os.getenv("MAX_ZIP_BYTES", str(2 * 1024 * 1024 * 1024)))
MAX_IMAGE_BYTES = int(os.getenv("MAX_IMAGE_BYTES", str(80 * 1024 * 1024)))
MAX_IMAGES_PER_ARCHIVE = int(os.getenv("MAX_IMAGES_PER_ARCHIVE", "20000"))
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff", ".heic", ".heif", ".avif"}

app = FastAPI(title=APP_NAME, version="0.1.0")

origins = [x.strip() for x in os.getenv("PHOTOTWIN_ALLOWED_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if origins == ["*"] else origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

def safe_name(name: str) -> str:
    return Path(name.replace("\\", "/")).name[:240] or "unnamed"

async def save_upload(upload: UploadFile, destination: Path) -> int:
    total = 0
    with destination.open("wb") as out:
        while True:
            chunk = await upload.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_ZIP_BYTES:
                raise HTTPException(status_code=413, detail=f"{upload.filename}: ZIP exceeds configured size limit.")
            out.write(chunk)
    await upload.close()
    return total

def hash_image(data: bytes) -> tuple[str, str | None, int | None, int | None]:
    sha = hashlib.sha256(data).hexdigest()
    phash = None
    width = height = None
    try:
        with Image.open(io.BytesIO(data)) as im:
            im = im.convert("RGB")
            im.thumbnail((512, 512))
            width, height = im.size
            phash = str(imagehash.phash(im))
    except (UnidentifiedImageError, OSError, ValueError):
        # Keep exact hash for formats PIL cannot decode; don't infer visual similarity.
        pass
    return sha, phash, width, height

def scan_zip(path: Path, account: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    try:
        with zipfile.ZipFile(path) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                p = Path(info.filename.replace("\\", "/"))
                if p.suffix.lower() not in IMAGE_EXTS:
                    continue
                if info.file_size > MAX_IMAGE_BYTES:
                    continue
                if len(items) >= MAX_IMAGES_PER_ARCHIVE:
                    raise HTTPException(status_code=413, detail=f"{account} export contains too many images (limit {MAX_IMAGES_PER_ARCHIVE}).")
                try:
                    with zf.open(info) as stream:
                        data = stream.read(MAX_IMAGE_BYTES + 1)
                    if len(data) > MAX_IMAGE_BYTES:
                        continue
                    sha, phash, width, height = hash_image(data)
                    items.append({
                        "account": account,
                        "name": safe_name(info.filename),
                        "path": info.filename[:500],
                        "size": info.file_size,
                        "sha256": sha,
                        "phash": phash,
                        "width": width,
                        "height": height,
                    })
                except (OSError, RuntimeError, zipfile.BadZipFile):
                    continue
    except zipfile.BadZipFile:
        raise HTTPException(status_code=400, detail=f"{account} file is not a valid ZIP archive.")
    return items

def compare(a_items: list[dict[str, Any]], b_items: list[dict[str, Any]]) -> dict[str, Any]:
    a_by_sha: dict[str, list[dict[str, Any]]] = defaultdict(list)
    b_by_sha: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in a_items:
        a_by_sha[item["sha256"]].append(item)
    for item in b_items:
        b_by_sha[item["sha256"]].append(item)

    exact = []
    for sha in (set(a_by_sha) & set(b_by_sha)):
        exact.append({"sha256": sha, "account_a": a_by_sha[sha], "account_b": b_by_sha[sha]})
    exact.sort(key=lambda x: x["account_a"][0]["name"].lower())

    # Find likely visually similar cross-account images not already exact matches.
    # For up to a few thousand photos this is simple and predictable; can be optimized later.
    exact_pairs = {(x["account_a"][0]["sha256"], x["account_b"][0]["sha256"]) for x in exact}
    a_phash = [x for x in a_items if x["phash"] and x["sha256"] not in b_by_sha]
    b_phash = [x for x in b_items if x["phash"] and x["sha256"] not in a_by_sha]
    similar = []
    for ai in a_phash:
        try:
            ah = imagehash.hex_to_hash(ai["phash"])
        except Exception:
            continue
        for bi in b_phash:
            try:
                bh = imagehash.hex_to_hash(bi["phash"])
                distance = ah - bh
            except Exception:
                continue
            if distance <= 5 and (ai["sha256"], bi["sha256"]) not in exact_pairs:
                similar.append({"distance": distance, "account_a": ai, "account_b": bi})
                if len(similar) >= 500:
                    break
        if len(similar) >= 500:
            break
    similar.sort(key=lambda x: x["distance"])

    a_sha = set(a_by_sha)
    b_sha = set(b_by_sha)
    a_only = [x for x in a_items if x["sha256"] not in b_sha]
    b_only = [x for x in b_items if x["sha256"] not in a_sha]

    return {
        "summary": {
            "account_a_images": len(a_items),
            "account_b_images": len(b_items),
            "exact_duplicate_hashes": len(exact),
            "likely_similar_pairs": len(similar),
            "account_a_only_files": len(a_only),
            "account_b_only_files": len(b_only),
            "note": "Counts refer to image files in the supplied ZIPs. Albums may include repeated copies of the same file.",
        },
        "exact_duplicates": exact,
        "likely_similar": similar,
        "account_a_only": a_only[:5000],
        "account_b_only": b_only[:5000],
    }

@app.get("/")
def root():
    return {"name": APP_NAME, "status": "ok", "version": "0.1.0"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/compare")
async def compare_exports(
    account_a: UploadFile = File(..., description="Google Takeout ZIP for Account A"),
    account_b: UploadFile = File(..., description="Google Takeout ZIP for Account B"),
):
    if not (account_a.filename or "").lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Account A export must be a .zip file.")
    if not (account_b.filename or "").lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Account B export must be a .zip file.")

    with tempfile.TemporaryDirectory(prefix="phototwin_") as temp_dir:
        base = Path(temp_dir)
        a_path = base / "account_a.zip"
        b_path = base / "account_b.zip"
        try:
            await save_upload(account_a, a_path)
            await save_upload(account_b, b_path)
            a_items = scan_zip(a_path, "A")
            b_items = scan_zip(b_path, "B")
            if not a_items and not b_items:
                raise HTTPException(status_code=400, detail="No supported image files found in either ZIP.")
            return compare(a_items, b_items)
        finally:
            # TemporaryDirectory removes archives and extracted-in-memory work on exit.
            pass
