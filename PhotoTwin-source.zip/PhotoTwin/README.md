# PhotoTwin — Google Photos Duplicate Finder

PhotoTwin is a mobile-friendly, privacy-conscious **export comparison MVP**. It compares two Google Photos Takeout ZIP exports and produces:
- exact duplicates found in both exports (SHA-256)
- likely similar images (perceptual hash)
- files seen only in Account A or only in Account B

## Important limitations
- Google does not provide a general API for an app to enumerate and delete every existing Google Photos item in a user's library. PhotoTwin therefore does **not** sign into Google Photos or delete cloud photos.
- Google Takeout export creation must be authorized on Google's own page. The app links to Takeout and explains the workflow; it cannot silently create exports.
- This MVP uploads each Takeout ZIP to the backend for processing. If you have no free phone storage, export to Google Drive from Takeout and use a computer/cloud workflow to transfer the ZIP to the backend. Direct Drive-to-backend OAuth import is not included in this first version.
- The backend temporarily stores uploads while scanning, then deletes temporary files. Deploy on a service with sufficient disk space for your ZIPs and extracted processing.
- Similar-image matches are suggestions, not proof. Review before deleting anything.
- This is an MVP, not a production security-audited service. Do not upload sensitive archives to a public deployment. Use a private deployment and add authentication before real personal use.

## Project structure
- `backend/` FastAPI scanner
- `frontend/` React + Vite mobile UI

## Run locally
### Backend
```bash
cd backend
python -m venv .venv
# activate venv
pip install -r requirements.txt
uvicorn main:app --reload
```
Backend runs at `http://127.0.0.1:8000`.

### Frontend
```bash
cd frontend
npm install
# create .env with VITE_API_BASE_URL=http://127.0.0.1:8000
npm run dev
```

## Deploy
1. Deploy `backend/` as a Python web service (Render or similar). Set build command `pip install -r requirements.txt`, start command `uvicorn main:app --host 0.0.0.0 --port $PORT`. Ensure enough disk/memory for your exports.
2. Set `PHOTOTWIN_ALLOWED_ORIGINS` to the deployed frontend URL (comma-separated if multiple).
3. Deploy `frontend/` to Vercel. Set `VITE_API_BASE_URL` to the backend URL.
4. Use private access only. Do not publish an unauthenticated scanner with personal exports.

## Use
1. Open Google Takeout: https://takeout.google.com/
2. Select only Google Photos, create an export, and save the export ZIP(s).
3. In PhotoTwin, select the ZIP for Account A and the ZIP for Account B.
4. Tap **Compare exports** and review the report.
5. PhotoTwin never deletes anything. Delete confirmed extra copies manually in Google Photos after verifying the other account still has its own copy.

Google Takeout may split large exports into multiple ZIP files. This MVP accepts one ZIP per account at a time; run separate comparisons for each matching set, or combine the report workflow in a later version.
